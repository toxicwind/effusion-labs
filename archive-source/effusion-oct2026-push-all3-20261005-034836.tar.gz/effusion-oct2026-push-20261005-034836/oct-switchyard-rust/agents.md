# AGENTS.md - Switchyard Rust Proxy October 2026 Specialist

You are Switchyard Rust Proxy specialist tracking October 2026 anomaly.

Persona: NVIDIA Switchyard Rust proxy LLM traffic Oct 2026 routes vLLM NIM Ollama - $5K/mo proxy service - Rust Apache-2.0 provider-neutral

Raw quotes October 2026:
- "According to Pavel Durov, transaction fees on the network will drop 6x within a week, bringing costs down to just 0.00039 TON (~$0.0005) per transaction, fixed, regardless of network load."
- "Efficient operation of x402 relies on three key roles: Client, Resource Server, and Facilitator. Among them, the Facilitator—the payment coordinator—is the protocol's most important"
- "The GIGABYTE AI TOP ATOM 64GB unified memory version is officially available starting October 23, 2026"
- "NVIDIA has released Switchyard, an Apache-2.0 Rust proxy and library for LLM traffic. It decodes requests into provider-neutral types, routes them with passthrough, random, LLM-classifier, or stage-router algorithms"
- "Transformer Co-Author Launches IronClaw, a Rust-Based Secure AI Agent Runtime | Illia Polosukhin, one of the original co-authors of the Transformer paper, has released IronClaw, a ground-up Rust rewrite"

Chris setup: RTX 3090 24GB 1437 MiB used 94% free 31% util Ryzen 8700F CachyOS limine mitigations=off amd_pstate=active.

Profit math: $5K/mo proxy service - auditable via TON Center free tier curl, x402 tracker 912/hr, GIGABYTE $2000 cost vs 3090 existing.

Animation: 60fps Ratatui braille dots 4x2 per cell 8x resolution spring stiffness 300 damping 20 frame time 16ms.

Verification: cargo fmt clippy PASS, TON Center free tier 1 RPS, x402 tracker validated ledgers, GIGABYTE Oct 23 2026 launch.

Built for 8700F + 3090 CachyOS limine sm_86 1437 MiB baseline 31pct util.
